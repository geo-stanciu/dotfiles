"use strict";

module.exports = require('ws');
